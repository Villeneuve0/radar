<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Radar - Numero</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/pagina2.css">
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-ZWFZZKGLH0"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-ZWFZZKGLH0');
    </script>
    <script type="text/javascript">
        (function(c,l,a,r,i,t,y){
            c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
            t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
            y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
        })(window, document, "clarity", "script", "odlzgzltce");
    </script>
</head>
<body>
    <header class="header">
        <img src="assets/images/logo-radar.png" alt="WhatsSpy Logo" class="logo">
    </header>

    <main class="main-content">
        <div class="box">
            <h2 class="red-text">Você ganhou <strong><span class="highlight">1 Acesso Gratuito</span></strong>, após investigar um número não será possível procurar outro na versão gratuita!</h2>
            <img src="assets/images/image-2.png" alt="Phones" class="phones-img">
            <p>Por favor, forneça o <strong>número de WhatsApp</strong> da pessoa que você deseja <strong>investigar</strong>, incluindo o <strong>DDD</strong>:</p>
            <div class="input-container">
                <div class="country-code">
                    <span class="flag">
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 55.2 38.4" style="width: 24px; height: 16px;">
                            <style type="text/css">
                                .st0{fill:#009B3A;} .st1{fill:#FEDF00;} .st2{fill:#002776;} .st3{fill:#FFFFFF;}
                            </style>
                            <g>
                                <path class="st0" d="M3.03,0h49.13c1.67,0,3.03,1.36,3.03,3.03v32.33c0,1.67-1.36,3.03-3.03,3.03H3.03C1.36,38.4,0,37.04,0,35.37V3.03C0,1.36,1.36,0,3.03,0L3.03,0z"/>
                                <polygon class="st1" points="4.24,19.2 27.6,34.11 50.96,19.2 27.6,4.29 4.24,19.2"/>
                                <path class="st2" d="M27.6,9.35c5.44,0,9.85,4.41,9.85,9.85c0,5.44-4.41,9.85-9.85,9.85c-5.44,0-9.85-4.41-9.85-9.85 C17.75,13.76,22.16,9.35,27.6,9.35L27.6,9.35z"/>
                                <path class="st3" d="M18.59,15.22c1.1-0.16,2.23-0.24,3.38-0.24c5.86,0,11.22,2.11,15.38,5.6c-0.07,0.54-0.19,1.06-0.35,1.56 c-3.98-3.58-9.25-5.76-15.03-5.76c-1.33,0-2.64,0.12-3.91,0.34C18.2,16.2,18.38,15.7,18.59,15.22L18.59,15.22z"/>
                            </g>
                        </svg>
                    </span>
                    <span>+55</span>
                </div>
                <input id="js_input-phonenumber" type="tel" class="input-phone" placeholder="(11) 90000-0000" maxlength="15">
            </div>
            <button id="start-btn" class="btn green">CLONAR WHATSAPP AGORA</button>            
            <p class="status">
                <span class="blinking-dot"></span> Investigações acontecendo agora
            </p>
            <div class="phone-list">
                <div class="phone-item">
                    <img src="assets/profiles/profile1.png" alt="Profile" class="profile-pic">
                    <span>+55 88 99823-****</span>
                </div>
                <div class="phone-item">
                    <img src="assets/profiles/profile2.png" alt="Profile" class="profile-pic">
                    <span>+55 21 98371-****</span>
                </div>
                <div class="phone-item">
                    <img src="assets/profiles/profile3.png" alt="Profile" class="profile-pic">
                    <span>+55 57 97263-****</span>
                </div>
            </div>

            <div id="loading-section" class="loading-section">
                <!-- Barra de progresso -->
                <div class="progress-bar">
                    <div class="progress-bar-fill">0%</div>
                </div>
                <div id="process-container">
                    <!-- Passos de carregamento -->
                    <div class="step">
                        <div class="icon loading"></div>
                        <span>Iniciando rastreamento...</span>
                    </div>
                    <div class="step">
                        <div class="icon"></div>
                        <span>Enviando requisição HTTPS...</span>
                    </div>
                    <div class="step">
                        <div class="icon"></div>
                        <span>Procurando vulnerabilidade na aplicação web...</span>
                    </div>
                    <div class="step">
                        <div class="icon"></div>
                        <span>Vulnerabilidade encontrada no código QR Temporário...</span>
                    </div>
                    <div class="step">
                        <div class="icon"></div>
                        <span>Autenticação do número de telefone com o WhatsApp Web...</span>
                    </div>
                    <div class="step">
                        <div class="icon"></div>
                        <span id="location-step">Supostas localizações suspeitas em CIDADE e região...</span>
                    </div>
                    <div class="step">
                        <div class="icon"></div>
                        <span>Descobri que passou a noite no Motel.</span>
                    </div>
                    <div class="step">
                        <div class="icon"></div>
                        <span>Obtendo chats, fotos, áudios, vídeos e contatos...</span>
                    </div>
                    <div class="step">
                        <div class="icon"></div>
                        <span>O WhatsApp foi clonado, abrindo o WhatsApp Web...</span>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="footer">
        <img src="assets/images/logo-radar.png" alt="WhatsSpy Logo" class="footer-logo">
        <p>Termos de Uso - Políticas de Privacidade</p>
        <p>WhatsSpy 2024 ©</p>
    </footer>
    <script src="js/pagina2.js"></script>
    <script src="js/script.js"></script>
    </body>
</html>
